import os
import socket
import sys
import threading

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from port_scanner import parse_ports, scan_port  # noqa: E402


def test_parse_ports_mixed():
    assert parse_ports("22,80,100-102") == [22, 80, 100, 101, 102]


def test_parse_ports_filters_invalid():
    assert parse_ports("0,70000,443") == [443]


def test_scan_detects_open_port():
    server = socket.socket()
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    port = server.getsockname()[1]
    threading.Thread(target=server.accept, daemon=True).start()
    result = scan_port("127.0.0.1", port, 1.0)
    server.close()
    assert result is not None and result[0] == port


def test_scan_closed_port_returns_none():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    assert scan_port("127.0.0.1", port, 0.5) is None
