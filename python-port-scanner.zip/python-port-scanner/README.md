# Python Port Scanner

A basic multithreaded TCP port scanner with service labeling, banner grabbing, and JSON/CSV export. Built with only the Python standard library.

> **Legal notice:** Only scan systems you own or have explicit written permission to test. Unauthorized scanning may be illegal.

## Features

- Fast scanning with a thread pool (configurable thread count)
- Port ranges and lists (`22,80,443` or `1-1024`)
- Common service name lookup (SSH, HTTP, MySQL, RDP, and more)
- Banner grabbing for services that announce themselves (SSH, FTP, SMTP)
- Export results to JSON or CSV
- No external dependencies

## Requirements

Python 3.8+

## Usage

```bash
python port_scanner.py <host> [-p PORTS] [-t THREADS] [--timeout SECONDS] [-o FILE]
```

| Option | Description | Default |
|---|---|---|
| `host` | Target hostname or IP | required |
| `-p, --ports` | Ports, e.g. `22,80,443` or `1-1024` | `1-1024` |
| `-t, --threads` | Number of worker threads | `100` |
| `--timeout` | Connection timeout in seconds | `1.0` |
| `-o, --output` | Save results to `.json` or `.csv` | none |

### Examples

```bash
python port_scanner.py 127.0.0.1
python port_scanner.py scanme.nmap.org -p 22,80,443
python port_scanner.py 192.168.1.10 -p 1-65535 -t 200 -o results.json
```

## Sample output

```
Scanning 127.0.0.1 (127.0.0.1) - 182 ports
Started: 2026-11-26 12:46:43

PORT    SERVICE     BANNER
8080    http-alt    

Done. 1 open port(s) found.
```

## How it works

1. Resolves the hostname to an IP address.
2. Opens a TCP connection to each port using `socket.connect_ex()`. A return of `0` means the port is open (full TCP connect scan).
3. For open ports, sends a newline and reads the first line the service returns as the banner.
4. Prints a report and optionally saves it.

## Tests

```bash
pip install pytest
pytest
```

## Limitations and ideas for improvement

- TCP connect scan only (no SYN or UDP scanning)
- Basic banner grabbing, not full version detection
- IPv4 only

Possible next steps: UDP scan mode, IPv6 support, HTTP banner probing, and a progress bar.

## Author

Sreyas, Junior Cybersecurity Analyst

## License

MIT
