#!/usr/bin/env python3
"""Basic multithreaded TCP port scanner with banner grabbing.

Only scan hosts you own or have explicit permission to test.
Example: python port_scanner.py 127.0.0.1 -p 1-1024 -t 100 -o results.json
"""
import argparse
import csv
import json
import socket
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

COMMON_SERVICES = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns",
    80: "http", 110: "pop3", 143: "imap", 443: "https",
    445: "smb", 3306: "mysql", 3389: "rdp", 5432: "postgres", 8080: "http-alt",
}


def parse_ports(spec):
    """Turn '22,80,1000-1010' into a sorted list of valid ports."""
    ports = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-")
            ports.update(range(int(start), int(end) + 1))
        else:
            ports.add(int(part))
    return sorted(p for p in ports if 1 <= p <= 65535)


def grab_banner(sock):
    """Try to read a one-line service banner."""
    try:
        sock.sendall(b"\r\n")
        data = sock.recv(1024).decode(errors="ignore").strip()
        return data.split("\n")[0] if data else ""
    except (socket.timeout, OSError):
        return ""


def scan_port(host, port, timeout):
    """Return (port, banner) if the port is open, else None."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            if sock.connect_ex((host, port)) == 0:
                return port, grab_banner(sock)
    except OSError:
        pass
    return None


def save_results(path, host, ip, results):
    rows = [
        {"port": p, "service": COMMON_SERVICES.get(p, "unknown"), "banner": b}
        for p, b in results
    ]
    if path.endswith(".csv"):
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["port", "service", "banner"])
            writer.writeheader()
            writer.writerows(rows)
    else:
        report = {
            "host": host, "ip": ip,
            "scanned_at": datetime.now().isoformat(timespec="seconds"),
            "open_ports": rows,
        }
        with open(path, "w") as f:
            json.dump(report, f, indent=2)


def main():
    parser = argparse.ArgumentParser(description="Simple TCP port scanner")
    parser.add_argument("host", help="Target hostname or IP (with permission!)")
    parser.add_argument("-p", "--ports", default="1-1024", help="e.g. 22,80,443 or 1-1024")
    parser.add_argument("-t", "--threads", type=int, default=100)
    parser.add_argument("--timeout", type=float, default=1.0)
    parser.add_argument("-o", "--output", help="Save results to .json or .csv")
    args = parser.parse_args()

    try:
        ip = socket.gethostbyname(args.host)
    except socket.gaierror:
        raise SystemExit(f"Could not resolve {args.host}")

    ports = parse_ports(args.ports)
    print(f"Scanning {args.host} ({ip}) - {len(ports)} ports")
    print(f"Started: {datetime.now():%Y-%m-%d %H:%M:%S}\n")

    with ThreadPoolExecutor(max_workers=args.threads) as pool:
        results = pool.map(lambda p: scan_port(ip, p, args.timeout), ports)
        open_ports = [r for r in results if r]

    print(f"{'PORT':<8}{'SERVICE':<12}BANNER")
    for port, banner in open_ports:
        print(f"{port:<8}{COMMON_SERVICES.get(port, 'unknown'):<12}{banner[:60]}")

    print(f"\nDone. {len(open_ports)} open port(s) found.")

    if args.output:
        save_results(args.output, args.host, ip, open_ports)
        print(f"Results saved to {args.output}")


if __name__ == "__main__":
    main()
